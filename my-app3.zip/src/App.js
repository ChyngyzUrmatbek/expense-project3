
import './App.css';
import Expenses from './components/Expenses/Expenses'
import {NewExpense} from './components/NewExpense/NewExpenses'

const expenses =[
  {
    title:'Туалетная бумага',
    price:300 ,
    date:new Date()
  },
  {
    title:'Зарядник',
    price:400 ,
    date:new Date()
  },
]

function App() {
  return (
    <div className="App">
      <header className='header'>
       <NewExpense/> 
      </header>
  
  
<section>
   <Expenses  expenses={expenses}/>
</section>
 
    </div>
  );
}

export default App;

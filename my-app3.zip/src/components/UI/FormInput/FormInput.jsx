import './FormInput.css'
const FormInput = (props)=>{
    return(
        <div className='form-input' >
            <label htmlFor={props.id}>{props.LableName}</label>
            <input className='input' placeholder={props.placeholder || '...'} id={props.id} type={props.inputType}/>
        </div>
    )
}

export default FormInput
import Button from "../UI/button/Button"
import FormInput from "../UI/FormInput/FormInput"
import './ExpenseForm.css'
export const ExpenseForm =(props)=>{
    const cancelHandler = (event)=>{
      event.preventDefault()
    props.onShowForm()
    }
    return(
        <form  className="expense-form">
     <FormInput
     id='name'
     LableName='Название'
     type='text'
     placeholder='Введите ...'
     />

<FormInput
    id='price'
     LableName='Количество денег'
     type='number'
     placeholder=''
     />
<FormInput
     id='date'
     LableName='Дата'
     type='date'
     placeholder='дд.мм.гггг'
     />
     <div className="btn-wrapp">
         <Button   title='Отмена' onClick={cancelHandler}/>
     <Button  title='Сохранить расходы'/></div>  
       
        </form>
    )
}